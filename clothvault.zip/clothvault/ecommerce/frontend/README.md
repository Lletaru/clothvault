# 👗 VogueVault — Clothing & Fashion E-Commerce Project

A beginner-friendly, multi-page e-commerce website built with **HTML**, **CSS (Bootstrap 5)**, and **vanilla JavaScript**. No frameworks, no backend, no installation required.

---

## 📁 Project Structure

```
voguevault/
│
├── index.html          → Product listing (home) page
├── product.html        → Product detail page
├── cart.html           → Shopping cart page
├── checkout.html       → Checkout + payment form
├── login.html          → Login & Register page
│
├── css/
│   └── style.css       → All custom styles for the site
│
└── js/
    ├── products.js     → Product data + shared helper functions
    ├── cart.js         → Cart logic (add, remove, localStorage, badge)
    ├── listing.js      → Product grid + filtering (index.html)
    ├── detail.js       → Product detail page logic (product.html)
    ├── cart-page.js    → Cart page rendering (cart.html)
    ├── checkout.js     → Checkout form + order summary (checkout.html)
    └── auth.js         → Login & register logic (login.html)
```

---

## 🚀 How to Run the Project

**No installation needed!**

1. Download or unzip the project folder
2. Open the `voguevault/` folder
3. Double-click **`index.html`** to open it in your browser
4. Navigate through the site using the links

> 💡 **Tip:** For the best experience, use **Google Chrome** or **Firefox**. Some browsers restrict `localStorage` when opening files directly — if the cart isn't saving, try using VS Code's **Live Server** extension.

---

## 🗺️ How to Navigate

| Page | File | How to reach it |
|------|------|----------------|
| 🏠 Shop (Home) | `index.html` | Click **VOGUEVAULT** logo or **Shop** link |
| 👗 Product Detail | `product.html` | Click any product card or its image |
| 🛒 Cart | `cart.html` | Click the bag icon (top right) |
| 💳 Checkout | `checkout.html` | Click **Proceed to Checkout** on the cart page |
| 👤 Login / Register | `login.html` | Click the person icon (top right) |

---

## 📄 Page-by-Page Explanation

### 1. `index.html` — Product Listing Page
- Displays all 8 products in a responsive grid (4 columns → 2 → 1 on mobile)
- **Filter buttons** at the top let you show products by category
- Each card has a **Quick Add** button and links to the product detail page
- The **Hero Banner** at the top is purely decorative/branding

### 2. `product.html` — Product Detail Page
- Shows full product info: image, name, description, price, star rating
- Lets you **select a size** and **choose a quantity**
- **Add to Cart** button saves the item to the cart (with localStorage)
- Gets the product to show via the URL: `product.html?id=3`

### 3. `cart.html` — Shopping Cart
- Lists all items added to the cart with image, name, size, quantity, price
- **Remove** (✕) button removes individual items
- **Order Summary** sidebar shows subtotal, shipping ($9.99 or FREE over $100), and total
- **Proceed to Checkout** takes you to the checkout form

### 4. `checkout.html` — Checkout Form
- **Left column:** Shipping form (name, email, address, country)
- **Right column:** Order summary mirrored from the cart
- **Payment section:** Card number, name, expiry, CVV fields
  - Card number auto-formats: `1234 5678 9012 3456`
  - Expiry auto-formats: `12 / 25`
- Submitting the form shows a **success message** and clears the cart

### 5. `login.html` — Login & Register
- **Tab-based UI:** Switch between Login and Register without reloading
- **Register:** Saves user data (name, email, password) to localStorage
- **Login:** Checks saved credentials and logs you in
- **Password strength meter** updates as you type
- **Show/Hide password** toggle on both forms

---

## 🔑 Key Concepts Explained

### localStorage
Think of `localStorage` like a tiny notepad built into every browser. We use it to:
- Save the shopping cart (so it survives page navigation)
- Save registered user accounts (for the login simulation)

```javascript
// Saving data
localStorage.setItem('key', JSON.stringify(data));

// Reading data
const data = JSON.parse(localStorage.getItem('key'));
```

### URL Query Parameters
We pass the product ID through the URL when linking to the detail page:
```
product.html?id=3
```
Then in JavaScript we read it like this:
```javascript
const params = new URLSearchParams(window.location.search);
const id = params.get('id'); // "3"
```

### Event Listeners
JavaScript "listens" for user actions (clicks, typing) and runs code in response:
```javascript
button.addEventListener('click', function() {
  // This runs when the button is clicked
});
```

### Array Methods Used
| Method | What it does |
|--------|-------------|
| `map()` | Transforms each item in an array into something new |
| `filter()` | Keeps only items that match a condition |
| `find()` | Returns the first item matching a condition |
| `reduce()` | Collapses an array into a single value (used for totals) |

---

## 🎨 Design Decisions

- **Fonts:** Playfair Display (headings) + DM Sans (body) — elegant, fashion-forward
- **Color palette:** Dark charcoal `#1a1612` + gold accent `#c8963e` + warm off-white background
- **CSS Variables:** All colors and fonts are stored in `:root` variables for easy theming
- **Responsive design:** Bootstrap's grid system (`col-6 col-md-4 col-lg-3`) handles all screen sizes

---

## 🏫 E-Commerce Theory: What This Project Demonstrates

| Concept | Where it appears |
|---------|-----------------|
| **Product Catalogue** | `index.html` + `products.js` |
| **Product Information Page** | `product.html` |
| **Shopping Cart** | `cart.html` + `cart.js` |
| **Checkout Flow** | `checkout.html` |
| **User Authentication** | `login.html` + `auth.js` |
| **Client-side Data Persistence** | `localStorage` (simulates a database) |
| **Responsive Design** | Bootstrap grid + CSS media queries |
| **Navigation & UX** | Navbar, breadcrumbs, filter bar |

---

## ⚠️ Important Notes (For the Course)

1. **This is a frontend-only prototype.** In a production system, you would need:
   - A backend server (Node.js, PHP, Python, etc.)
   - A real database (MySQL, MongoDB, etc.)
   - Secure password hashing (never store plain text passwords!)
   - A real payment gateway (Stripe, PayPal, Flutterwave, etc.)

2. **Passwords in localStorage are NOT secure** — this is only for learning purposes.

3. **Product images** are loaded from Unsplash.com (free image service). An internet connection is required to see them.

---

## 🛠️ Possible Extensions (For Extra Credit)

- Add a **search bar** that filters products by name
- Add a **"wishlist" / save for later** feature
- Make product quantities editable directly in the cart
- Add a **product ratings & reviews** section
- Integrate a **real payment API** like Flutterwave (popular in Uganda/Africa)
- Add **more products** by editing the `PRODUCTS` array in `js/products.js`

---

*Built with ❤️ using HTML, CSS (Bootstrap 5), and vanilla JavaScript.*
