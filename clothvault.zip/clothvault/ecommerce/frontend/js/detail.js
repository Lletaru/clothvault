/* ============================================================
   detail.js — Product Detail Page Logic
   
   How it works:
   1. Read the product ID from the URL query parameter (?id=3)
   2. Look up that product in the PRODUCTS array
   3. Fill in all the page elements with the product's data
   4. Handle size selection and quantity changes
   5. Handle "Add to Cart" button
   ============================================================ */


// Tracks which size the user has selected (starts as null = none chosen)
let selectedSize = null;

// Tracks quantity the user wants (starts at 1)
let currentQty = 1;


/* ============================================================
   loadProductDetail()
   Main function that fills the page with product data.
   Called once when the page loads.
   ============================================================ */
function loadProductDetail() {

  // --- Step 1: Get the product ID from the URL ---
  // window.location.search = "?id=3"
  // URLSearchParams makes it easy to extract individual parameters
  const params = new URLSearchParams(window.location.search);
  const productId = params.get('id'); // Returns "3" as a string

  // --- Step 2: Find the product in our data ---
  const product = getProductById(productId);

  // If no product found (e.g. bad URL), redirect back to shop
  if (!product) {
    alert("Product not found!");
    window.location.href = "index.html";
    return;
  }

  // --- Step 3: Update the page <title> ---
  document.title = `VOGUE VAULT – ${product.name}`;

  // --- Step 4: Fill in each element by its ID ---
  document.getElementById('detail-img').src = product.image;
  document.getElementById('detail-img').alt = product.name;
  document.getElementById('detail-name').textContent = product.name;
  document.getElementById('detail-price').textContent = formatPrice(product.price);
  document.getElementById('detail-desc').textContent = product.desc;

  // Capitalise the category for display (e.g. "dresses" → "Dresses")
  document.getElementById('detail-category').textContent =
    product.category.charAt(0).toUpperCase() + product.category.slice(1);

  // Update breadcrumb with product name
  document.getElementById('breadcrumb-name').textContent = product.name;

  // --- Step 5: Render size buttons ---
  const sizeContainer = document.getElementById('size-options');
  sizeContainer.innerHTML = product.sizes.map(size => `
    <button class="size-btn" onclick="selectSize('${size}', this)">${size}</button>
  `).join('');
}


/* ============================================================
   selectSize(size, btn)
   Called when a size button is clicked.
   Highlights the selected button and stores the choice.
   ============================================================ */
function selectSize(size, btn) {
  selectedSize = size;

  // Remove 'selected' class from all size buttons
  document.querySelectorAll('.size-btn').forEach(b => b.classList.remove('selected'));

  // Add 'selected' to the clicked button
  btn.classList.add('selected');
}


/* ============================================================
   changeQty(delta)
   Called by the + and - buttons.
   delta is +1 or -1.
   ============================================================ */
function changeQty(delta) {
  // Prevent going below 1
  currentQty = Math.max(1, currentQty + delta);

  // Update the display
  document.getElementById('qty-display').textContent = currentQty;
}


/* ============================================================
   addToCartFromDetail()
   Called when "Add to Cart" is clicked on the detail page.
   Validates that a size was selected, then adds to cart.
   ============================================================ */
function addToCartFromDetail() {
  // Validate: a size must be selected
  if (!selectedSize) {
    alert("Please select a size first!");
    return;
  }

  // Get the current product from the URL again
  const params = new URLSearchParams(window.location.search);
  const product = getProductById(params.get('id'));

  if (!product) return;

  // Add to cart using the shared cart function
  addToCart(product, selectedSize, currentQty);
}


/* ============================================================
   Run when page loads
   ============================================================ */
document.addEventListener('DOMContentLoaded', loadProductDetail);
