/* ============================================================
   checkout.js — Checkout Page Logic
   
   Responsibilities:
   1. Display cart items in the order summary sidebar
   2. Calculate and show totals
   3. Handle form submission → show success message
   4. Card number and expiry date formatting helpers
   ============================================================ */


/* ============================================================
   loadCheckoutSummary()
   Fills the right sidebar with a list of items and totals.
   ============================================================ */
function loadCheckoutSummary() {
  const cart = getCart();
  const container = document.getElementById('checkout-items');

  if (cart.length === 0) {
    container.innerHTML = '<p class="text-muted small">Your cart is empty.</p>';
    return;
  }

  // Render each item as a simple row with name and price
  container.innerHTML = cart.map(item => `
    <div class="co-item">
      <span>${item.name} <span class="text-muted">(${item.size}) ×${item.quantity}</span></span>
      <span>${formatPrice(item.price * item.quantity)}</span>
    </div>
  `).join('');

  // Calculate totals (same logic as cart-page.js)
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const shipping = subtotal >= 100 ? 0 : 9.99;
  const total = subtotal + shipping;

  document.getElementById('co-subtotal').textContent = formatPrice(subtotal);
  document.getElementById('co-shipping').textContent =
    shipping === 0 ? 'FREE' : formatPrice(shipping);
  document.getElementById('co-total').textContent = formatPrice(total);
}


/* ============================================================
   placeOrder(event)
   Called when the checkout form is submitted.
   Prevents the default browser form behaviour, shows success message,
   and clears the cart.
   ============================================================ */
function placeOrder(event) {
  // Prevent the page from refreshing (default HTML form behaviour)
  event.preventDefault();

  // Hide the checkout form
  document.getElementById('checkout-form').style.display = 'none';

  // Show the success message
  document.getElementById('order-success').style.display = 'block';

  // Clear the cart (order has been placed)
  localStorage.removeItem('voguevault_cart');

  // Update the cart badge to 0
  updateCartBadge();

  // Scroll to top so user sees the success message
  window.scrollTo({ top: 0, behavior: 'smooth' });
}


/* ============================================================
   formatCard(input)
   Automatically formats a card number as the user types:
   "1234567890123456" → "1234 5678 9012 3456"
   ============================================================ */
function formatCard(input) {
  // Remove all non-digit characters
  let val = input.value.replace(/\D/g, '');

  // Insert a space every 4 characters using regex
  val = val.replace(/(.{4})/g, '$1 ').trim();

  // Update the input field
  input.value = val;
}


/* ============================================================
   formatExpiry(input)
   Automatically formats expiry as: "1225" → "12 / 25"
   ============================================================ */
function formatExpiry(input) {
  // Remove all non-digit characters
  let val = input.value.replace(/\D/g, '');

  // After the first 2 digits, add " / "
  if (val.length >= 3) {
    val = val.substring(0, 2) + ' / ' + val.substring(2, 4);
  }

  input.value = val;
}


/* ============================================================
   Run when page loads
   ============================================================ */
document.addEventListener('DOMContentLoaded', loadCheckoutSummary);
