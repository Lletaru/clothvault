/* ============================================================
   auth.js — Login & Register Page Logic
   
   IMPORTANT NOTE FOR STUDENTS:
   This is a FRONTEND-ONLY simulation. In a real application:
   - Passwords would be hashed on the server (never stored as plain text)
   - Authentication would use sessions or JWT tokens
   - User data would be stored in a real database (not localStorage)
   
   Here we use localStorage to simulate the experience for learning purposes.
   ============================================================ */


/* ============================================================
   handleLogin(event)
   Called when the login form is submitted.
   ============================================================ */
function handleLogin(event) {
  event.preventDefault(); // Stop page refresh

  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-pass').value;
  const errorBox = document.getElementById('login-error');

  // Check if a user with this email was previously registered
  const savedUser = localStorage.getItem('vv_user_' + email);

  if (!savedUser) {
    // No account found for this email
    showError(errorBox, 'No account found with this email. Please register.');
    return;
  }

  // Parse the saved user object
  const user = JSON.parse(savedUser);

  // Check password match
  // (In real apps: compare hashed passwords on the server)
  if (user.password !== password) {
    showError(errorBox, 'Incorrect password. Please try again.');
    return;
  }

  // SUCCESS: Save a "logged in" session flag
  localStorage.setItem('vv_logged_in', JSON.stringify({
    name: user.firstName,
    email: user.email
  }));

  // Show success toast then redirect to shop
  showToast(`Welcome back, ${user.firstName}! 👋`);

  setTimeout(() => {
    window.location.href = 'index.html';
  }, 1500);
}


/* ============================================================
   handleRegister(event)
   Called when the registration form is submitted.
   ============================================================ */
function handleRegister(event) {
  event.preventDefault();

  const firstName = document.getElementById('reg-fname').value;
  const lastName = document.getElementById('reg-lname').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-pass').value;
  const errorBox = document.getElementById('register-error');

  // Check if this email is already registered
  if (localStorage.getItem('vv_user_' + email)) {
    showError(errorBox, 'An account with this email already exists. Please log in.');
    return;
  }

  // Validate password length
  if (password.length < 6) {
    showError(errorBox, 'Password must be at least 6 characters.');
    return;
  }

  // Save the user in localStorage
  // Key format: "vv_user_jane@example.com" so each user has a unique key
  const user = { firstName, lastName, email, password };
  localStorage.setItem('vv_user_' + email, JSON.stringify(user));

  // Auto-login after registration
  localStorage.setItem('vv_logged_in', JSON.stringify({ name: firstName, email }));

  showToast(`Account created! Welcome, ${firstName}! 🎉`);

  setTimeout(() => {
    window.location.href = 'index.html';
  }, 1500);
}


/* ============================================================
   showError(element, message)
   Shows an error message in the alert box.
   ============================================================ */
function showError(element, message) {
  element.textContent = message;
  element.classList.remove('d-none'); // Remove Bootstrap's hidden class

  // Auto-hide after 4 seconds
  setTimeout(() => element.classList.add('d-none'), 4000);
}


/* ============================================================
   togglePassword(inputId, btn)
   Toggles password visibility when the eye icon is clicked.
   Changes the input type between "password" and "text".
   ============================================================ */
function togglePassword(inputId, btn) {
  const input = document.getElementById(inputId);
  const icon = btn.querySelector('i');

  if (input.type === 'password') {
    input.type = 'text';                  // Show password
    icon.className = 'bi bi-eye-slash';   // Change icon
  } else {
    input.type = 'password';              // Hide password
    icon.className = 'bi bi-eye';         // Restore icon
  }
}


/* ============================================================
   switchTab(tabId)
   Programmatically switches between Login and Register tabs.
   Called by the "Create one →" and "Sign in →" links.
   ============================================================ */
function switchTab(tabId) {
  // Use Bootstrap's Tab API to activate the tab
  const tabEl = document.getElementById(tabId);
  const tab = new bootstrap.Tab(tabEl);
  tab.show();
}


/* ============================================================
   PASSWORD STRENGTH METER
   Updates a coloured bar and label as the user types their password.
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  const passInput = document.getElementById('reg-pass');
  if (!passInput) return; // Only run on register tab

  passInput.addEventListener('input', function () {
    const val = this.value;
    const bar = document.getElementById('strength-bar');
    const label = document.getElementById('strength-label');

    // Determine strength based on length and character variety
    let strength = '';
    let labelText = '';

    if (val.length === 0) {
      // Empty: reset
      bar.className = 'password-strength';
      label.textContent = '';
    } else if (val.length < 6) {
      // Too short = weak
      bar.className = 'password-strength strength-weak';
      label.textContent = 'Weak';
    } else if (val.length < 10 || !/[A-Z]/.test(val) || !/[0-9]/.test(val)) {
      // Medium length or missing uppercase/numbers
      bar.className = 'password-strength strength-medium';
      label.textContent = 'Medium';
    } else {
      // Long, has uppercase and numbers = strong
      bar.className = 'password-strength strength-strong';
      label.textContent = 'Strong';
    }
  });
});
