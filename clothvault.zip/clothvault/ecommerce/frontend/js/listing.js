/* ============================================================
   listing.js — Product Listing Page Logic
   
   Responsibilities:
   1. Render all product cards on the page
   2. Handle category filtering (when user clicks a filter button)
   3. Handle "Quick Add" — add a product without going to its page
   ============================================================ */


/* ============================================================
   renderProducts(products)
   Takes an array of product objects and builds HTML card elements,
   then injects them into the #product-grid container.
   ============================================================ */
function renderProducts(products) {
  // Get the grid container from the DOM
  const grid = document.getElementById('product-grid');

  // If no products match the filter, show a message
  if (products.length === 0) {
    grid.innerHTML = `
      <div class="col-12 text-center py-5 text-muted">
        <p>No products found in this category.</p>
      </div>
    `;
    return;
  }

  // Build the HTML for each product card
  // map() transforms each product into an HTML string
  // join('') combines all strings into one big string
  grid.innerHTML = products.map(product => `
    <div class="col-6 col-md-4 col-lg-3">
      <div class="product-card h-100">

        <!-- Clicking the image or name navigates to the product detail page -->
        <!-- We pass the product ID in the URL as a query parameter: ?id=1 -->
        <a href="product.html?id=${product.id}" class="text-decoration-none text-dark">
          <div class="product-img-wrap">
            <img src="${product.image}" alt="${product.name}" loading="lazy"/>
            <!-- Category badge in top-left corner -->
            <span class="product-badge">${product.category}</span>
          </div>

          <div class="product-info">
            <p class="product-name">${product.name}</p>
            <p class="product-price mb-1">${formatPrice(product.price)}</p>
          </div>
        </a>

        <!-- Quick Add button (outside the <a> tag so it doesn't navigate away) -->
        <!-- onclick calls quickAdd() with this product's ID -->
        <div class="px-3 pb-3">
          <button class="btn-quick-add" onclick="quickAdd(${product.id})">
            + Quick Add
          </button>
        </div>

      </div>
    </div>
  `).join('');
}


/* ============================================================
   quickAdd(productId)
   Adds a product to the cart directly from the listing page,
   using the default first size, without going to the detail page.
   ============================================================ */
function quickAdd(productId) {
  const product = getProductById(productId);
  if (!product) return;

  // Use first available size as default
  const defaultSize = product.sizes[0];

  // Add 1 unit to cart
  addToCart(product, defaultSize, 1);
}


/* ============================================================
   FILTER LOGIC
   When a filter button is clicked, show only products in that category.
   "all" shows everything.
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {

  // Render all products when the page first loads
  renderProducts(PRODUCTS);

  // Get all filter buttons
  const filterBtns = document.querySelectorAll('.filter-btn');

  // Add a click listener to each button
  filterBtns.forEach(btn => {
    btn.addEventListener('click', function () {

      // Remove 'active' class from ALL buttons first
      filterBtns.forEach(b => b.classList.remove('active'));

      // Add 'active' to the clicked button (to highlight it)
      this.classList.add('active');

      // Read the filter value from data-filter attribute
      const filter = this.dataset.filter;

      if (filter === 'all') {
        // Show all products
        renderProducts(PRODUCTS);
      } else {
        // Filter the array: keep only products matching the category
        const filtered = PRODUCTS.filter(p => p.category === filter);
        renderProducts(filtered);
      }
    });
  });

});
