/* ============================================================
   cart.js — Shared Cart Logic
   
   This file is loaded on EVERY page. It handles:
   - Reading the cart from localStorage (so it persists across pages)
   - Adding/removing items
   - Updating the cart badge count in the navbar
   
   KEY CONCEPT: localStorage
   localStorage lets us save data in the browser that stays
   even after you reload the page or navigate away.
   Think of it as a tiny database built into every browser.
   
   We store the cart as a JSON string, and parse it when we need it.
   ============================================================ */


/* ============================================================
   getCart()
   Reads the cart array from localStorage.
   If nothing is saved yet, returns an empty array [].
   ============================================================ */
function getCart() {
  // localStorage.getItem returns a JSON string or null
  const raw = localStorage.getItem('voguevault_cart');
  
  // JSON.parse converts the string back into a JavaScript array
  // If raw is null (nothing saved yet), return an empty array
  return raw ? JSON.parse(raw) : [];
}


/* ============================================================
   saveCart(cart)
   Saves the cart array to localStorage.
   JSON.stringify converts the array into a string for storage.
   ============================================================ */
function saveCart(cart) {
  localStorage.setItem('voguevault_cart', JSON.stringify(cart));
}


/* ============================================================
   addToCart(product, size, quantity)
   Adds a product to the cart.
   
   If the same product + size already exists, increase quantity.
   Otherwise, add it as a new entry.
   ============================================================ */
function addToCart(product, size, quantity = 1) {
  const cart = getCart();

  // Check if this product + size combination already exists in cart
  const existing = cart.find(item => item.id === product.id && item.size === size);

  if (existing) {
    // Already in cart: just increase the quantity
    existing.quantity += quantity;
  } else {
    // New item: add it to the array
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      size: size,
      quantity: quantity
    });
  }

  // Save updated cart back to localStorage
  saveCart(cart);

  // Update the badge count on the navbar
  updateCartBadge();

  // Show a brief confirmation toast to the user
  showToast(`${product.name} added to cart!`);
}


/* ============================================================
   removeFromCart(productId, size)
   Removes all entries matching this product + size combination.
   ============================================================ */
function removeFromCart(productId, size) {
  let cart = getCart();

  // filter() keeps only items that DON'T match, effectively removing the target
  cart = cart.filter(item => !(item.id === productId && item.size === size));

  saveCart(cart);
  updateCartBadge();
}


/* ============================================================
   updateCartBadge()
   Counts total items in the cart and updates the red badge number.
   Called every time the cart changes.
   ============================================================ */
function updateCartBadge() {
  const cart = getCart();

  // Sum all quantities across all cart items
  const total = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Find the badge element on the page and update its text
  const badge = document.getElementById('cart-count');
  if (badge) {
    badge.textContent = total;

    // Hide badge if cart is empty (0 looks awkward)
    badge.style.display = total === 0 ? 'none' : 'flex';
  }
}


/* ============================================================
   showToast(message)
   Shows a small pop-up notification at the bottom of the screen.
   It automatically disappears after 2.5 seconds.
   ============================================================ */
function showToast(message) {
  // Create a div for the toast
  const toast = document.createElement('div');
  toast.className = 'vv-toast';
  toast.textContent = message;

  // Inject CSS directly (no need for extra CSS file)
  toast.style.cssText = `
    position: fixed;
    bottom: 2rem;
    left: 50%;
    transform: translateX(-50%) translateY(20px);
    background: #1a1612;
    color: #fff;
    padding: 0.75rem 1.75rem;
    border-radius: 50px;
    font-family: 'DM Sans', sans-serif;
    font-size: 0.875rem;
    z-index: 9999;
    opacity: 0;
    transition: all 0.3s ease;
    box-shadow: 0 8px 24px rgba(0,0,0,0.2);
    white-space: nowrap;
  `;

  document.body.appendChild(toast);

  // Trigger animation: fade in + slide up
  // setTimeout 0 ensures the element is in the DOM before animating
  setTimeout(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(-50%) translateY(0)';
  }, 10);

  // After 2.5 seconds, fade out and remove
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(-50%) translateY(10px)';
    setTimeout(() => toast.remove(), 300);
  }, 2500);
}


/* ============================================================
   AUTO-RUN ON PAGE LOAD
   Every time any page loads, update the cart badge.
   This ensures the number is always current.
   ============================================================ */
document.addEventListener('DOMContentLoaded', updateCartBadge);
