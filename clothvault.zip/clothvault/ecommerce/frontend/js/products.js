/* ============================================================
   products.js — Shared Product Data
   
   This file contains the product "database" for the store.
   In a real e-commerce site, this data would come from a 
   backend server (e.g. Node.js + MongoDB, or PHP + MySQL).
   
   For this project, we keep it simple: a plain JavaScript array.
   This file is loaded on EVERY page so all pages share the same data.
   ============================================================ */


// PRODUCTS ARRAY
// Each object = one product. 
// Fields:
//   id       – unique number to identify the product
//   name     – display name
//   category – used for filtering (must match filter button data-filter values)
//   price    – number (in USD)
//   image    – URL from Unsplash (free placeholder images)
//   desc     – short description shown on the product detail page
//   sizes    – array of available sizes

const PRODUCTS = [
  {
    id: 1,
    name: "Silk Wrap Midi Dress",
    category: "dresses",
    price: 9.99,
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=600&q=80",
    desc: "Effortlessly elegant, this silk wrap midi dress drapes beautifully and transitions seamlessly from day to evening. Features a flattering round-neckline and adjustable tie waist.",
    sizes: ["XS", "S", "M", "L", "XL"]
  },
  {
    id: 2,
    name: "Cropped Linen Blazer",
    category: "outerwear",
    price: 14.00,
    image: "https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=600&q=80",
    desc: "A summer-ready linen blazer with a relaxed crop silhouette. Perfect over a slip dress or with tailored trousers for a polished look.",
    sizes: ["XS", "S", "M", "L"]
  },
  {
    id: 3,
    name: "High-Rise Wide-Leg Trousers",
    category: "bottoms",
    price: 24.00,
    image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&q=80",
    desc: "These high-rise wide-leg trousers elongate the silhouette beautifully. Crafted from a fluid crepe fabric that holds shape all day.",
    sizes: ["XS", "S", "M", "L", "XL"]
  },
  {
    id: 4,
    name: "Ribbed Knit Crop Top",
    category: "tops",
    price: 5.50,
    image: "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?w=600&q=80",
    desc: "A versatile ribbed knit crop top that pairs with everything from high-waisted jeans to maxi skirts. Soft, stretchy, and perfectly fitted.",
    sizes: ["XS", "S", "M", "L"]
  },
  {
    id: 5,
    name: "Floral Chiffon Maxi Dress",
    category: "dresses",
    price: 27.00,
    image: "https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=600&q=80",
    desc: "Romantic and flowing, this chiffon maxi dress features a delicate floral print and flutter sleeves. An instant wardrobe favourite.",
    sizes: ["XS", "S", "M", "L", "XL"]
  },
  {
    id: 6,
    name: "Oversized Trench Coat",
    category: "outerwear",
    price: 88.00,
    image: "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=600&q=80",
    desc: "A timeless trench coat with an oversized silhouette. Double-breasted front, belted waist, and storm flap — the ultimate transitional layer.",
    sizes: ["S", "M", "L", "XL"]
  },
  {
    id: 7,
    name: "Pleated Mini Skirt",
    category: "bottoms",
    price: 24.00,
    image: "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=600&q=80",
    desc: "A flirty pleated mini skirt in a lightweight satin fabric. Pairs perfectly with a tucked-in blouse or an oversized knit.",
    sizes: ["XS", "S", "M", "L"]
  },
  {
    id: 8,
    name: "Relaxed Linen Button Shirt",
    category: "tops",
    price: 12.00,
    image: "https://images.unsplash.com/photo-1542060748-10c28b62716f?w=600&q=80",
    desc: "Easy-going and breathable, this relaxed linen shirt is perfect for warm days. Wear open over a cami or tucked in for a smart-casual look.",
    sizes: ["XS", "S", "M", "L", "XL", "XXL"]
  }
];


/* ============================================================
   HELPER FUNCTION: formatPrice
   Converts a number like 89.99 → "$89.99"
   Used throughout the project to display prices consistently.
   ============================================================ */
function formatPrice(amount) {
  // toFixed(2) ensures two decimal places always (e.g. 89.9 → "89.90")
  return "$" + parseFloat(amount).toFixed(2);
}


/* ============================================================
   HELPER FUNCTION: getProductById
   Looks up a product by its ID from the PRODUCTS array.
   Returns the product object, or null if not found.
   ============================================================ */
function getProductById(id) {
  // parseInt converts string "3" to number 3 for comparison
  return PRODUCTS.find(p => p.id === parseInt(id)) || null;
}
