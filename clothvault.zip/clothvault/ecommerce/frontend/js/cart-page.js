/* ============================================================
   cart-page.js — Cart Page Logic
   
   Responsibilities:
   1. Render all items in the cart as rows
   2. Show an empty state if cart is empty
   3. Allow removing items
   4. Calculate and display subtotal, shipping, and total
   ============================================================ */


/* ============================================================
   renderCartPage()
   Reads the cart from localStorage and builds the cart UI.
   ============================================================ */
function renderCartPage() {
  const cart = getCart();
  const container = document.getElementById('cart-items-container');

  // --- EMPTY CART STATE ---
  if (cart.length === 0) {
    container.innerHTML = `
      <div class="empty-cart">
        <i class="bi bi-bag-x"></i>
        <h5>Your cart is empty</h5>
        <p class="text-muted mb-4">Looks like you haven't added anything yet.</p>
        <a href="index.html" class="btn btn-add-cart px-4">Start Shopping</a>
      </div>
    `;

    // Set totals to zero
    document.getElementById('summary-subtotal').textContent = formatPrice(0);
    document.getElementById('summary-shipping').textContent = formatPrice(0);
    document.getElementById('summary-total').textContent = formatPrice(0);
    return;
  }

  // --- RENDER CART ITEMS ---
  // Build HTML for each item in the cart
  container.innerHTML = cart.map(item => `
    <div class="cart-item-row">

      <!-- Product thumbnail -->
      <img class="cart-item-img" src="${item.image}" alt="${item.name}"/>

      <!-- Product info -->
      <div class="flex-grow-1">
        <p class="cart-item-name">${item.name}</p>
        <p class="cart-item-meta">Size: ${item.size} &nbsp;|&nbsp; Qty: ${item.quantity}</p>
        <p class="cart-item-price">${formatPrice(item.price * item.quantity)}</p>
      </div>

      <!-- Remove button: calls removeItem() with this item's ID and size -->
      <button class="btn-remove" 
              onclick="removeItem(${item.id}, '${item.size}')"
              title="Remove item">
        <i class="bi bi-x-lg"></i>
      </button>

    </div>
  `).join('');

  // --- CALCULATE TOTALS ---
  // Subtotal = sum of (price × quantity) for all items
  const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  // Shipping: free if subtotal is over $100, else $9.99
  const shipping = subtotal >= 100 ? 0 : 9.99;

  const total = subtotal + shipping;

  // Update the summary section
  document.getElementById('summary-subtotal').textContent = formatPrice(subtotal);
  document.getElementById('summary-shipping').textContent =
    shipping === 0 ? 'FREE' : formatPrice(shipping);
  document.getElementById('summary-total').textContent = formatPrice(total);
}


/* ============================================================
   removeItem(productId, size)
   Removes an item from the cart and re-renders the page.
   ============================================================ */
function removeItem(productId, size) {
  // Call the shared removeFromCart function from cart.js
  removeFromCart(productId, size);

  // Re-render the cart page to reflect the change
  renderCartPage();
}


/* ============================================================
   Run when page loads
   ============================================================ */
document.addEventListener('DOMContentLoaded', renderCartPage);
