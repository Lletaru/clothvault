const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bcrypt = require("bcrypt");

const app = express();
app.use(cors());
app.use(express.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "clothvault_db"
});

/* AUTH */
app.post("/register", async (req, res) => {
  const { name, email, password } = req.body;
  const hash = await bcrypt.hash(password, 10);

  db.query(
    "INSERT INTO users (name,email,password) VALUES (?,?,?)",
    [name, email, hash],
    (err) => {
      if (err) return res.send(err);
      res.send("Registered");
    }
  );
});

app.post("/login", (req, res) => {
  const { email, password } = req.body;

  db.query("SELECT * FROM users WHERE email=?", [email], async (err, result) => {
    if (result.length === 0) return res.send("User not found");

    const match = await bcrypt.compare(password, result[0].password);
    if (!match) return res.send("Wrong password");

    res.json(result[0]);
  });
});

/* PRODUCTS */
app.get("/products", (req, res) => {
  db.query("SELECT * FROM products", (err, result) => {
    res.json(result);
  });
});

app.post("/products", (req, res) => {
  const { name, price, image, category } = req.body;

  db.query(
    "INSERT INTO products (name,price,image,category) VALUES (?,?,?,?)",
    [name, price, image, category],
    () => res.send("Product added")
  );
});

/* CART */
app.post("/cart", (req, res) => {
  const { user_id, product_id, quantity } = req.body;

  db.query(
    "INSERT INTO cart (user_id,product_id,quantity) VALUES (?,?,?)",
    [user_id, product_id, quantity],
    () => res.send("Added to cart")
  );
});

/* CHECKOUT */
app.post("/checkout", (req, res) => {
  const { user_id, items } = req.body;

  let total = 0;
  items.forEach(i => total += i.price * i.quantity);

  db.query(
    "INSERT INTO orders (user_id,total) VALUES (?,?)",
    [user_id, total],
    (err, orderRes) => {

      const order_id = orderRes.insertId;

      items.forEach(item => {
        db.query(
          "INSERT INTO order_items (order_id,product_id,quantity,price) VALUES (?,?,?,?)",
          [order_id, item.id, item.quantity, item.price]
        );
      });

      res.send("Order placed successfully");
    }
  );
});

app.listen(5000, () => console.log("Server running on port 5000"));